package com.helpme3;

public class VOMyTalkList {
	private String mt_code     = null; //개인채팅방코드_PK
	private String mt_yourid   = null; //상대방 아이디
	private String mt_fcolor   = null; //내 폰트 색
	private String mt_bcolor   = null; //내 배경 색
	private String mem_id      = null; //내 아이디_FK
	
	public String getMt_code() {
		return mt_code;
	}
	public void setMt_code(String mt_code) {
		this.mt_code = mt_code;
	}
	public String getMt_yourid() {
		return mt_yourid;
	}
	public void setMt_yourid(String mt_yourid) {
		this.mt_yourid = mt_yourid;
	}
	public String getMt_fcolor() {
		return mt_fcolor;
	}
	public void setMt_fcolor(String mt_fcolor) {
		this.mt_fcolor = mt_fcolor;
	}
	public String getMt_bcolor() {
		return mt_bcolor;
	}
	public void setMt_bcolor(String mt_bcolor) {
		this.mt_bcolor = mt_bcolor;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	
}
