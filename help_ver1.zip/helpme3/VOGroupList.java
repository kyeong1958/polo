package com.helpme3;

public class VOGroupList {
	private String glist_code   = null; //단톡코드_FK(GroupCode)_PK :복합키
	private String mem_id       = null; //회원아이디_FK(MEM)_PK : 복합키
	private String glist_fcolor = null; //단톡글자색
	private String glist_bcolor = null; //단톡배갱색
	private String glist_gimg   = null; //단톡이미지
	
	public String getGlist_code() {
		return glist_code;
	}
	public void setGlist_code(String glist_code) {
		this.glist_code = glist_code;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getGlist_fcolor() {
		return glist_fcolor;
	}
	public void setGlist_fcolor(String glist_fcolor) {
		this.glist_fcolor = glist_fcolor;
	}
	public String getGlist_bcolor() {
		return glist_bcolor;
	}
	public void setGlist_bcolor(String glist_bcolor) {
		this.glist_bcolor = glist_bcolor;
	}
	public String getGlist_gimg() {
		return glist_gimg;
	}
	public void setGlist_gimg(String glist_gimg) {
		this.glist_gimg = glist_gimg;
	}
}
