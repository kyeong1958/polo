package com.helpme3;

public class VOGroupCode {
	private String gcode_code  = null; // 그룹코드_PK
	private String gcode_total = null; // 현재인원수
	private String gcode_name  = null; // 그룹방명
	
	public String getGcode_code() {
		return gcode_code;
	}
	public void setGcode_code(String gcode_code) {
		this.gcode_code = gcode_code;
	}
	public String getGcode_total() {
		return gcode_total;
	}
	public void setGcode_total(String gcode_total) {
		this.gcode_total = gcode_total;
	}
	public String getGcode_name() {
		return gcode_name;
	}
	public void setGcode_name(String gcode_name) {
		this.gcode_name = gcode_name;
	}
}
