package com.helpme3;

public class Setting_notice {

}
