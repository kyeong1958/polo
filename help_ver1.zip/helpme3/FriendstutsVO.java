package com.helpme3;

public class FriendstutsVO {
	int di = 0;

	public int getDi() {
		return di;
	}

	public void setDi(int di) {
		this.di = di;
	}
}
