package com.helpme3;

public class VOSetting {
	private String set_font    = null; //폰트
	private String set_fcolor  = null; //폰트 색상
	private String set_fsize   = null; //폰트 사이즈
	private String set_bcolor  = null; //배경색
	private String mem_id      = null; //아이디_PK
	
	public String getSet_font() {
		return set_font;
	}
	public void setSet_font(String set_font) {
		this.set_font = set_font;
	}
	public String getSet_fcolor() {
		return set_fcolor;
	}
	public void setSet_fcolor(String set_fcolor) {
		this.set_fcolor = set_fcolor;
	}
	public String getSet_fsize() {
		return set_fsize;
	}
	public void setSet_fsize(String set_fsize) {
		this.set_fsize = set_fsize;
	}
	public String getSet_bcolor() {
		return set_bcolor;
	}
	public void setSet_bcolor(String set_bcolor) {
		this.set_bcolor = set_bcolor;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
}
