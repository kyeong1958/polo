package com.helpme3;

public class VOMyTalkLog {
	private int    mt_rno       = 0;    //순번_PK
	private String mt_date      = null; //작성날짜
	private String mt_time      = null; //작성시간
	private String mt_contents  = null; //작성내용
	private String mt_writer    = null; //작성자
	private String mt_code      = null; //채팅방코드_FK(MyTalk)
	
	public int getMt_rno() {
		return mt_rno;
	}
	public void setMt_rno(int mt_rno) {
		this.mt_rno = mt_rno;
	}
	public String getMt_date() {
		return mt_date;
	}
	public void setMt_date(String mt_date) {
		this.mt_date = mt_date;
	}
	public String getMt_time() {
		return mt_time;
	}
	public void setMt_time(String mt_time) {
		this.mt_time = mt_time;
	}
	public String getMt_contents() {
		return mt_contents;
	}
	public void setMt_contents(String mt_contents) {
		this.mt_contents = mt_contents;
	}
	public String getMt_writer() {
		return mt_writer;
	}
	public void setMt_writer(String mt_writer) {
		this.mt_writer = mt_writer;
	}
	public String getMt_code() {
		return mt_code;
	}
	public void setMt_code(String mt_code) {
		this.mt_code = mt_code;
	}
}
